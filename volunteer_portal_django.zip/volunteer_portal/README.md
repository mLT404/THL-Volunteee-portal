# Riverbend Volunteer Portal (Django backend)

A Django backend for the volunteer login/sign-up page, adding:

- **Sign up / Log in** — same clipboard-styled form, now backed by real accounts.
- **Dashboard** — a volunteer's own attendance summary and latest notices.
- **Notice board** — announcements visible to every logged-in volunteer; admins (staff accounts) can post new ones.
- **Directory** — shared info: every volunteer's name, interest area, and join date.
- **My Attendance** — a volunteer's own attendance history.
- **Mark Attendance** (staff only) — admins mark present/absent/excused per volunteer per date; it shows up instantly on that volunteer's dashboard and attendance page.

This has **not been run in this sandbox** (no internet access here to install Django), so treat it as a complete, ready-to-run first draft — test it locally and fix anything version-specific to the Django release you install.

## Setup

```bash
# 1. Create and activate a virtual environment
python3 -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Create the database tables
python manage.py makemigrations
python manage.py migrate

# 4. Create an admin (staff) account — this is who can post notices and mark attendance
python manage.py createsuperuser

# 5. Run the dev server
python manage.py runserver
```

Visit `http://127.0.0.1:8000/` to sign up or log in as a volunteer.
Visit `http://127.0.0.1:8000/admin/` to log in with the superuser account and manage everything from Django's built-in admin too.

## How the pieces fit together

- `volunteers/models.py` — `Profile` (extra volunteer info attached to Django's built-in `User`), `Notice`, `AttendanceRecord`.
- `volunteers/forms.py` — sign-up form (creates `User` + `Profile` together), styled login form, notice form, attendance form.
- `volunteers/views.py` — one view per page; attendance-marking and notice-posting are restricted to staff accounts via a `staff_required` decorator.
- `volunteers/urls.py` — all routes live under the `volunteers` app; log in is the site root (`/`).
- `volunteers/templates/` — `base.html` holds the nav bar, everything else extends it.
- `volunteers/static/volunteers/css/style.css` — the shared paper/clipboard visual style from the original page.

## Making someone an admin

Any user with `is_staff=True` can post notices and mark attendance. Set this either with `createsuperuser`, or for an existing account:

```bash
python manage.py shell -c "
from django.contrib.auth.models import User
u = User.objects.get(email='someone@example.com')
u.is_staff = True
u.save()
"
```

## Notes / next steps

- `DEBUG = True` and the `SECRET_KEY` in `settings.py` are for local development only — replace both before deploying anywhere public.
- Attendance is one record per volunteer per date (`unique_together`), so re-marking the same date updates it rather than duplicating it.
- The database is SQLite by default (zero setup); swap `DATABASES` in `settings.py` for Postgres/MySQL when you're ready to deploy.
