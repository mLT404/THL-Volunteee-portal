from django.conf import settings
from django.db import models


class Profile(models.Model):
    """Extra volunteer info attached one-to-one to Django's built-in User."""

    INTEREST_CHOICES = [
        ('food-bank', 'Food bank & pantry'),
        ('tutoring', 'Youth tutoring'),
        ('park-cleanup', 'Park & trail cleanup'),
        ('senior-visits', 'Senior visits'),
        ('events', 'Event support'),
    ]

    user = models.OneToOneField(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='profile'
    )
    phone = models.CharField(max_length=20, blank=True)
    interest = models.CharField(max_length=20, choices=INTEREST_CHOICES)
    joined_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.user.get_full_name() or self.user.username

    def attendance_summary(self):
        """Return counts of each attendance status for this volunteer."""
        records = self.attendance_records.all()
        return {
            'present': records.filter(status=AttendanceRecord.PRESENT).count(),
            'absent': records.filter(status=AttendanceRecord.ABSENT).count(),
            'excused': records.filter(status=AttendanceRecord.EXCUSED).count(),
            'total': records.count(),
        }


class Notice(models.Model):
    """A notice-board post visible to every logged-in volunteer."""

    title = models.CharField(max_length=200)
    body = models.TextField()
    pinned = models.BooleanField(default=False)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-pinned', '-created_at']

    def __str__(self):
        return self.title


class AttendanceRecord(models.Model):
    """One attendance mark for one volunteer on one date, set by an admin."""

    PRESENT = 'present'
    ABSENT = 'absent'
    EXCUSED = 'excused'
    STATUS_CHOICES = [
        (PRESENT, 'Present'),
        (ABSENT, 'Absent'),
        (EXCUSED, 'Excused'),
    ]

    volunteer = models.ForeignKey(
        Profile, on_delete=models.CASCADE, related_name='attendance_records'
    )
    date = models.DateField()
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default=PRESENT)
    note = models.CharField(max_length=200, blank=True)
    marked_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name='+'
    )
    marked_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-date']
        unique_together = ('volunteer', 'date')

    def __str__(self):
        return f'{self.volunteer} — {self.date} — {self.get_status_display()}'
