from django.contrib.auth import views as auth_views
from django.urls import path

from . import views
from .forms import StyledAuthenticationForm

app_name = 'volunteers'

urlpatterns = [
    path('', auth_views.LoginView.as_view(
        template_name='volunteers/auth.html',
        authentication_form=StyledAuthenticationForm,
        extra_context={'active_tab': 'login'},
        redirect_authenticated_user=True,
    ), name='login'),
    path('signup/', views.signup_view, name='signup'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),

    path('dashboard/', views.dashboard_view, name='dashboard'),
    path('notices/', views.notice_board_view, name='notice_board'),
    path('notices/new/', views.notice_create_view, name='notice_create'),
    path('directory/', views.directory_view, name='directory'),
    path('attendance/', views.my_attendance_view, name='my_attendance'),
    path('attendance/manage/', views.admin_attendance_view, name='admin_attendance'),
]
