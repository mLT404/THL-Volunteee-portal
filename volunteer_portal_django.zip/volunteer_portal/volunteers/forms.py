from django import forms
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django.contrib.auth.models import User

from .models import AttendanceRecord, Notice, Profile


TEXT_WIDGET = forms.TextInput(attrs={'placeholder': ''})


class StyledAuthenticationForm(AuthenticationForm):
    """Django's login form, restyled to match the portal's look."""

    username = forms.CharField(
        widget=forms.TextInput(attrs={'placeholder': 'you@example.com', 'autofocus': True})
    )
    password = forms.CharField(
        widget=forms.PasswordInput(attrs={'placeholder': 'Enter your password'})
    )


class SignUpForm(UserCreationForm):
    """Creates a User plus its linked volunteer Profile in one form."""

    first_name = forms.CharField(max_length=30, required=True)
    last_name = forms.CharField(max_length=30, required=True)
    email = forms.EmailField(required=True)
    phone = forms.CharField(max_length=20, required=False)
    interest = forms.ChoiceField(choices=Profile.INTEREST_CHOICES)

    class Meta:
        model = User
        fields = [
            'first_name', 'last_name', 'email',
            'phone', 'interest', 'password1', 'password2',
        ]

    def clean_email(self):
        email = self.cleaned_data['email']
        if User.objects.filter(email__iexact=email).exists():
            raise forms.ValidationError('An account with this email already exists.')
        return email

    def save(self, commit=True):
        user = super().save(commit=False)
        user.username = self.cleaned_data['email']
        user.email = self.cleaned_data['email']
        user.first_name = self.cleaned_data['first_name']
        user.last_name = self.cleaned_data['last_name']
        if commit:
            user.save()
            Profile.objects.create(
                user=user,
                phone=self.cleaned_data.get('phone', ''),
                interest=self.cleaned_data['interest'],
            )
        return user


class NoticeForm(forms.ModelForm):
    class Meta:
        model = Notice
        fields = ['title', 'body', 'pinned']
        widgets = {
            'body': forms.Textarea(attrs={'rows': 5}),
        }


class AttendanceForm(forms.ModelForm):
    class Meta:
        model = AttendanceRecord
        fields = ['volunteer', 'date', 'status', 'note']
        widgets = {
            'date': forms.DateInput(attrs={'type': 'date'}),
        }
