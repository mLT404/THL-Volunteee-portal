from django.contrib import admin

from .models import AttendanceRecord, Notice, Profile


@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'interest', 'phone', 'joined_at')
    search_fields = ('user__first_name', 'user__last_name', 'user__email')
    list_filter = ('interest',)


@admin.register(Notice)
class NoticeAdmin(admin.ModelAdmin):
    list_display = ('title', 'pinned', 'created_by', 'created_at')
    list_filter = ('pinned',)


@admin.register(AttendanceRecord)
class AttendanceRecordAdmin(admin.ModelAdmin):
    list_display = ('volunteer', 'date', 'status', 'marked_by')
    list_filter = ('status', 'date')
    search_fields = ('volunteer__user__first_name', 'volunteer__user__last_name')
