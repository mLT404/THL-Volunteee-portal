from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required, user_passes_test
from django.shortcuts import get_object_or_404, redirect, render

from .forms import AttendanceForm, NoticeForm, SignUpForm
from .models import AttendanceRecord, Notice, Profile


def staff_required(view_func):
    """Only lets staff/admin accounts through; everyone else is bounced home."""
    return user_passes_test(lambda u: u.is_authenticated and u.is_staff, login_url='volunteers:dashboard')(view_func)


def signup_view(request):
    if request.user.is_authenticated:
        return redirect('volunteers:dashboard')

    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Account created — welcome to the team.')
            return redirect('volunteers:dashboard')
    else:
        form = SignUpForm()

    return render(request, 'volunteers/auth.html', {
        'signup_form': form,
        'active_tab': 'signup',
    })


@login_required
def dashboard_view(request):
    profile = request.user.profile
    summary = profile.attendance_summary()
    recent_notices = Notice.objects.all()[:3]
    recent_attendance = profile.attendance_records.all()[:5]
    return render(request, 'volunteers/dashboard.html', {
        'profile': profile,
        'summary': summary,
        'recent_notices': recent_notices,
        'recent_attendance': recent_attendance,
    })


@login_required
def notice_board_view(request):
    notices = Notice.objects.all()
    return render(request, 'volunteers/notice_board.html', {'notices': notices})


@staff_required
def notice_create_view(request):
    if request.method == 'POST':
        form = NoticeForm(request.POST)
        if form.is_valid():
            notice = form.save(commit=False)
            notice.created_by = request.user
            notice.save()
            messages.success(request, 'Notice posted to the board.')
            return redirect('volunteers:notice_board')
    else:
        form = NoticeForm()
    return render(request, 'volunteers/notice_form.html', {'form': form})


@login_required
def directory_view(request):
    profiles = Profile.objects.select_related('user').order_by('user__first_name')
    return render(request, 'volunteers/directory.html', {'profiles': profiles})


@login_required
def my_attendance_view(request):
    profile = request.user.profile
    records = profile.attendance_records.all()
    summary = profile.attendance_summary()
    return render(request, 'volunteers/my_attendance.html', {
        'records': records,
        'summary': summary,
    })


@staff_required
def admin_attendance_view(request):
    if request.method == 'POST':
        form = AttendanceForm(request.POST)
        if form.is_valid():
            volunteer = form.cleaned_data['volunteer']
            date = form.cleaned_data['date']
            record, _created = AttendanceRecord.objects.update_or_create(
                volunteer=volunteer, date=date,
                defaults={
                    'status': form.cleaned_data['status'],
                    'note': form.cleaned_data['note'],
                    'marked_by': request.user,
                },
            )
            messages.success(
                request,
                f'Marked {volunteer} as {record.get_status_display()} for {date}.',
            )
            return redirect('volunteers:admin_attendance')
    else:
        form = AttendanceForm()

    recent_records = AttendanceRecord.objects.select_related('volunteer__user')[:20]
    return render(request, 'volunteers/admin_attendance.html', {
        'form': form,
        'recent_records': recent_records,
    })
